#!/usr/bin/env python

__author__ = "bt3"


test = lambda x: x**2
print test(3)